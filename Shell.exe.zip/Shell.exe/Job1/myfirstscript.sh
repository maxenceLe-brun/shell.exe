echo "i'm a script"
