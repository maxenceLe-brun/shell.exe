apt-get update
apt-get upgrade
