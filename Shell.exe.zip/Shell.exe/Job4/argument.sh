touch $1
echo $2 > $1
