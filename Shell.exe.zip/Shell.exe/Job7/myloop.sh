cpt=1
while((cpt<11))
do
	echo "Je suis un script qui arrive a faire une boucle $cpt"
	((cpt+=1))
done
exit 0
